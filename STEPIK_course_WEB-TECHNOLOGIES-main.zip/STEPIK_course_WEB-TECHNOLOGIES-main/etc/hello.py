'''
empty file, becouse settings can be specified in enviroment
'''
